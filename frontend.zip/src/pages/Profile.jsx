import React from "react";

function Perfil() {
  return (
    <div>
      <h2>Perfil del estudiante</h2>
      <p>Aquí podrás actualizar tus datos personales.</p>
    </div>
  );
}

export default Perfil;