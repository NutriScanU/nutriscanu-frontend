import React from "react";

function StudentHome() {
  return (
    <div>
      <h1>Bienvenido al panel del estudiante 🎓</h1>
    </div>
  );
}

export default StudentHome;
