import React from "react";

function AnalysisStatus() {
  return (
    <div>
      <h2>Estado de tu análisis</h2>
      <p>Pronto recibirás los resultados de tu evaluación nutricional.</p>
    </div>
  );
}

export default AnalysisStatus;