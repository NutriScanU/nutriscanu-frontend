import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { loginUsuario } from "../services/authService";

function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mensaje, setMensaje] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMensaje("");
    try {
      const data = await loginUsuario({ email, password });
      localStorage.setItem("token", data.token);
      alert("Login exitoso");
      navigate("/student/home");
    } catch (error) {
      console.error(error);
      setMensaje("Correo o contraseña inválidos");
    }
  };

  return (
    <div style={{ maxWidth: 400, margin: "auto", paddingTop: "4rem" }}>
      <h2>Iniciar sesión</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder="Correo electrónico"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          style={{ width: "100%", marginBottom: 10, padding: 8 }}
        />
        <input
          type="password"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={{ width: "100%", marginBottom: 10, padding: 8 }}
        />
        {mensaje && <p style={{ color: "red" }}>{mensaje}</p>}
        <button type="submit" style={{ width: "100%", padding: 10 }}>
          Ingresar
        </button>

        {/* Enlace de recuperación */}
        <p style={{ marginTop: "1rem", textAlign: "center" }}>
          <span
            style={{
              color: "#007bff",
              textDecoration: "underline",
              cursor: "pointer",
            }}
            onClick={() => navigate("/forgot-password")}
          >
            ¿Olvidaste tu contraseña?
          </span>
        </p>
      </form>
    </div>
  );
}

export default Login;
