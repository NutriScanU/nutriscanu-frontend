import React from "react";

function Recommendations() {
  return (
    <div>
      <h2>Recomendaciones nutricionales</h2>
      <p>Aquí verás los consejos adaptados a tu salud.</p>
    </div>
  );
}

export default Recommendations;