import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "../pages/Login";
import Register from "../pages/Register";
import ForgotPassword from "../pages/ForgotPassword";
import ResetPassword from "../pages/ResetPassword";

import StudentLayout from "../layouts/StudentLayout";
import StudentHome from "../pages/Student/StudentHome";
import Profile from "../pages/Profile";
import AnalysisStatus from "../pages/AnalysisStatus";
import Recommendations from "../pages/Recommendations";

function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Públicas */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password/:token" element={<ResetPassword />} />

        {/* Rutas protegidas del estudiante */}
        <Route path="/student" element={<StudentLayout />}>
          <Route path="home" element={<StudentHome />} />
          <Route path="profile" element={<Profile />} />
          <Route path="analysis-status" element={<AnalysisStatus />} />
          <Route path="recommendations" element={<Recommendations />} />
        </Route>

        <Route path="*" element={<h1>Ruta no encontrada</h1>} />
      </Routes>
    </BrowserRouter>
  );
}

export default AppRouter;
